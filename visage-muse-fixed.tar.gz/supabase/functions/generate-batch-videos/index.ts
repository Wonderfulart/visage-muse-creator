import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { encode as base64Encode } from "https://deno.land/std@0.168.0/encoding/base64.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Generate JWT for service account authentication
async function generateJWT(serviceAccount: { client_email: string; private_key: string }): Promise<string> {
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    iss: serviceAccount.client_email,
    sub: serviceAccount.client_email,
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
    scope: 'https://www.googleapis.com/auth/cloud-platform'
  };

  const encodedHeader = base64Encode(JSON.stringify(header)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const encodedPayload = base64Encode(JSON.stringify(payload)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const signInput = `${encodedHeader}.${encodedPayload}`;

  const pemContent = serviceAccount.private_key
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\n/g, '');
  
  const binaryKey = Uint8Array.from(atob(pemContent), c => c.charCodeAt(0));
  
  const key = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    key,
    new TextEncoder().encode(signInput)
  );

  const encodedSignature = base64Encode(signature).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  return `${signInput}.${encodedSignature}`;
}

// Exchange JWT for access token
async function getAccessToken(serviceAccount: { client_email: string; private_key: string }): Promise<string> {
  const jwt = await generateJWT(serviceAccount);
  
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to get access token: ${error}`);
  }

  const data = await response.json();
  return data.access_token;
}

// Generate a single video scene
async function generateVideoScene(
  accessToken: string,
  serviceAccount: any,
  scene: {
    sceneDescription: string;
    duration: number;
    referenceImage?: string;
    preserveFace?: boolean;
    aspectRatio?: string;
  }
): Promise<{ requestId: string; sceneDescription: string }> {
  const projectId = serviceAccount.project_id;
  const location = 'us-central1';
  const modelId = 'veo-3.1-generate-001';
  const apiUrl = `https://${location}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${location}/publishers/google/models/${modelId}:predictLongRunning`;

  // Build enhanced prompt
  let enhancedPrompt = scene.sceneDescription;
  if (scene.preserveFace && scene.referenceImage) {
    enhancedPrompt = `${scene.sceneDescription}. Maintain exact facial features and identity of the person in the reference image.`;
  }

  // Build request body
  const requestBody: Record<string, unknown> = {
    instances: [{
      prompt: enhancedPrompt
    }],
    parameters: {
      aspectRatio: scene.aspectRatio || '16:9',
      durationSeconds: scene.duration || 5,
      sampleCount: 1,
      personGeneration: 'allow_all',
      addWatermark: true,
      generateAudio: true
    }
  };

  // Add reference image if provided
  if (scene.referenceImage) {
    const base64Match = scene.referenceImage.match(/^data:image\/(\w+);base64,(.+)$/);
    if (base64Match) {
      const mimeType = `image/${base64Match[1]}`;
      (requestBody.instances as Record<string, unknown>[])[0].image = {
        bytesBase64Encoded: base64Match[2],
        mimeType: mimeType
      };
    }
  }

  console.log('Generating scene:', scene.sceneDescription.substring(0, 50));

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody),
  });

  const responseText = await response.text();

  if (!response.ok) {
    console.error('Scene generation error:', responseText);
    throw new Error(`Scene generation failed: ${response.status}`);
  }

  const data = JSON.parse(responseText);
  const operationName = data.name;

  return {
    requestId: operationName,
    sceneDescription: scene.sceneDescription
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const serviceAccountJson = Deno.env.get('VERTEX_SERVICE_ACCOUNT');
    
    if (!serviceAccountJson) {
      console.error('VERTEX_SERVICE_ACCOUNT is not configured');
      return new Response(
        JSON.stringify({ error: 'Vertex AI service account not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let serviceAccount;
    try {
      serviceAccount = JSON.parse(serviceAccountJson);
    } catch {
      console.error('Failed to parse service account JSON');
      return new Response(
        JSON.stringify({ error: 'Invalid service account JSON format' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { scenes, referenceImage, preserveFace, aspectRatio } = await req.json();

    if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
      return new Response(
        JSON.stringify({ error: 'Scenes array is required and must not be empty' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (scenes.length > 10) {
      return new Response(
        JSON.stringify({ error: 'Maximum 10 scenes allowed per batch' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Batch generation starting: ${scenes.length} scenes`);

    // Get OAuth2 access token
    const accessToken = await getAccessToken(serviceAccount);

    // Generate all scenes in parallel
    const scenePromises = scenes.map((scene: any) => 
      generateVideoScene(accessToken, serviceAccount, {
        sceneDescription: scene.sceneDescription,
        duration: scene.duration,
        referenceImage: referenceImage,
        preserveFace: preserveFace,
        aspectRatio: aspectRatio
      })
    );

    const results = await Promise.allSettled(scenePromises);

    // Process results
    const operations: Array<{
      success: boolean;
      requestId?: string;
      sceneDescription?: string;
      order?: number;
      error?: string;
    }> = results.map((result, index) => {
      if (result.status === 'fulfilled') {
        return {
          success: true,
          requestId: result.value.requestId,
          sceneDescription: result.value.sceneDescription,
          order: scenes[index].order
        };
      } else {
        return {
          success: false,
          error: result.reason.message,
          sceneDescription: scenes[index].sceneDescription,
          order: scenes[index].order
        };
      }
    });

    const successCount = operations.filter(op => op.success).length;
    const failureCount = operations.filter(op => !op.success).length;

    console.log(`Batch generation initiated: ${successCount} succeeded, ${failureCount} failed`);

    return new Response(
      JSON.stringify({
        success: true,
        totalScenes: scenes.length,
        successCount,
        failureCount,
        operations,
        message: `Batch generation started for ${successCount} scenes`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in generate-batch-videos function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
