import { useState } from 'react';
import { Sparkles, Music, Zap, Palette, Film, Star, Flame, Heart } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

import { LucideIcon } from 'lucide-react';

export interface VideoTemplate {
  id: string;
  name: string;
  category: 'music-video' | 'performance' | 'cinematic' | 'abstract' | 'storytelling';
  icon: LucideIcon;
  description: string;
  sceneDescription: string;
  styleGuide: string;
  visualElements: string[];
  exampleScenes: string[];
  colorPalette: string;
  safetyTips: string[];
  avoidWords: string[];
  duration: number;
  aspectRatio: string;
  premium?: boolean;
}

const templates: VideoTemplate[] = [
  {
    id: 'cyberpunk-neon',
    name: 'Cyberpunk Dreams',
    category: 'music-video',
    icon: Zap,
    description: 'Futuristic cityscape with neon aesthetics, perfect for electronic music',
    sceneDescription: 'A figure stands in a rain-soaked alley illuminated by vibrant pink and cyan neon signs, with holographic advertisements floating in the air',
    styleGuide: 'Neon lighting, cyberpunk aesthetic, futuristic urban environment, cinematic framing',
    visualElements: ['neon signs', 'wet pavement reflections', 'holographic elements', 'futuristic architecture'],
    exampleScenes: [
      'Person walking through neon-lit street at night with rain',
      'Close-up with pink and cyan rim lighting',
      'Wide shot of futuristic cityscape with figure silhouette'
    ],
    colorPalette: 'Hot pink (#FF0080), cyan (#00FFFF), deep purple, black',
    safetyTips: [
      'Use "figure" or "person" instead of specific identities',
      'Describe lighting and atmosphere, not actions',
      'Focus on visual mood rather than narrative'
    ],
    avoidWords: ['explicit', 'violent', 'weapon', 'blood', 'death'],
    duration: 8,
    aspectRatio: '16:9'
  },
  {
    id: 'dreamy-ethereal',
    name: 'Ethereal Dreams',
    category: 'music-video',
    icon: Sparkles,
    description: 'Soft, dreamy aesthetic with floating elements and pastel colors',
    sceneDescription: 'A person surrounded by softly glowing orbs and flowing fabric, floating particles creating an otherworldly atmosphere with warm golden hour lighting',
    styleGuide: 'Soft focus, dreamy atmosphere, golden hour lighting, floating elements, gentle movement',
    visualElements: ['glowing particles', 'flowing fabric', 'bokeh effects', 'soft light rays'],
    exampleScenes: [
      'Person with eyes closed, surrounded by floating light particles',
      'Flowing fabric in slow motion with backlight',
      'Close-up with soft glow and lens flare'
    ],
    colorPalette: 'Soft gold, lavender, peach, cream white',
    safetyTips: [
      'Emphasize lighting and atmosphere',
      'Use "gentle" and "soft" movements',
      'Focus on visual beauty not specific actions'
    ],
    avoidWords: ['explicit', 'intimate', 'provocative'],
    duration: 8,
    aspectRatio: '16:9'
  },
  {
    id: 'performance-stage',
    name: 'Live Performance',
    category: 'performance',
    icon: Music,
    description: 'Dynamic stage performance with dramatic lighting',
    sceneDescription: 'A performer on stage with dramatic spotlights, smoke effects, and dynamic colored lighting creating an energetic concert atmosphere',
    styleGuide: 'Dynamic lighting, stage effects, energetic atmosphere, concert venue aesthetic',
    visualElements: ['stage lights', 'smoke effects', 'spotlight beams', 'silhouettes'],
    exampleScenes: [
      'Performer silhouette with backlight and smoke',
      'Dynamic colored stage lighting sweeping across scene',
      'Close-up with dramatic side lighting'
    ],
    colorPalette: 'Deep blues, vibrant reds, white spotlights, black shadows',
    safetyTips: [
      'Describe lighting setup not specific movements',
      'Use "performing" or "on stage" broadly',
      'Focus on atmosphere and mood'
    ],
    avoidWords: ['crowd', 'audience interaction', 'jumping', 'dancing'],
    duration: 8,
    aspectRatio: '16:9'
  },
  {
    id: 'nature-cinematic',
    name: 'Cinematic Nature',
    category: 'cinematic',
    icon: Palette,
    description: 'Epic nature cinematography with dramatic lighting',
    sceneDescription: 'A person standing on a cliff edge overlooking a vast landscape during golden hour, with dramatic clouds and sunbeams breaking through',
    styleGuide: 'Cinematic wide shots, dramatic natural lighting, epic scale, film-like quality',
    visualElements: ['dramatic skies', 'sunbeams', 'vast landscapes', 'silhouettes'],
    exampleScenes: [
      'Person silhouette against dramatic sunset sky',
      'Wide landscape shot with figure for scale',
      'Golden hour lighting with lens flare'
    ],
    colorPalette: 'Golden oranges, deep blues, earth tones, dramatic shadows',
    safetyTips: [
      'Focus on landscape and lighting',
      'Keep figure small in frame for scale',
      'Emphasize natural elements'
    ],
    avoidWords: ['climbing', 'jumping', 'dangerous', 'falling'],
    duration: 8,
    aspectRatio: '16:9'
  },
  {
    id: 'abstract-flow',
    name: 'Abstract Flow',
    category: 'abstract',
    icon: Flame,
    description: 'Abstract visual flow with organic movements and gradients',
    sceneDescription: 'Flowing abstract shapes and gradients morphing around a central figure, with smooth organic movements and vibrant color transitions',
    styleGuide: 'Abstract shapes, smooth gradients, organic flow, vibrant colors, artistic interpretation',
    visualElements: ['flowing shapes', 'color gradients', 'organic patterns', 'smooth transitions'],
    exampleScenes: [
      'Abstract colorful shapes flowing around figure',
      'Gradient transitions with smooth movement',
      'Close-up with abstract light patterns'
    ],
    colorPalette: 'Vibrant multi-color gradients, flowing from warm to cool tones',
    safetyTips: [
      'Focus on abstract visual elements',
      'Emphasize color and shape over realism',
      'Use artistic and interpretive language'
    ],
    avoidWords: ['realistic', 'detailed', 'specific actions'],
    duration: 8,
    aspectRatio: '9:16',
    premium: true
  },
  {
    id: 'emotional-portrait',
    name: 'Emotional Portrait',
    category: 'storytelling',
    icon: Heart,
    description: 'Intimate portrait style with emotional depth',
    sceneDescription: 'Close portrait shot with soft window lighting from the side, creating gentle shadows and highlighting facial features with warm natural light',
    styleGuide: 'Portrait photography style, natural lighting, shallow depth of field, emotional connection',
    visualElements: ['window light', 'soft shadows', 'bokeh background', 'natural skin tones'],
    exampleScenes: [
      'Close portrait with side window lighting',
      'Shallow depth of field with bokeh',
      'Warm natural light on face'
    ],
    colorPalette: 'Warm natural tones, soft shadows, creamy bokeh',
    safetyTips: [
      'Focus on lighting and mood',
      'Use "contemplative" or "thoughtful" expressions',
      'Emphasize technical photography elements'
    ],
    avoidWords: ['crying', 'extreme emotion', 'distress'],
    duration: 5,
    aspectRatio: '9:16',
    premium: true
  },
  {
    id: 'retro-vintage',
    name: 'Retro Vibes',
    category: 'music-video',
    icon: Film,
    description: '80s/90s inspired aesthetic with VHS effects',
    sceneDescription: 'A scene with vintage 80s aesthetic featuring VHS scan lines, chromatic aberration, and warm analog color grading with retro styling',
    styleGuide: 'VHS aesthetic, retro color grading, scan lines, chromatic aberration, 80s/90s vibe',
    visualElements: ['VHS effects', 'scan lines', 'chromatic aberration', 'retro colors'],
    exampleScenes: [
      'Person with VHS scan line effects',
      'Retro color grading with warm tones',
      'Wide shot with vintage film grain'
    ],
    colorPalette: 'Warm oranges, teal shadows, magenta highlights, desaturated',
    safetyTips: [
      'Emphasize visual effects and style',
      'Focus on retro aesthetic elements',
      'Use period-appropriate styling'
    ],
    avoidWords: ['modern', 'contemporary', 'digital'],
    duration: 8,
    aspectRatio: '16:9'
  },
  {
    id: 'minimal-elegance',
    name: 'Minimal Elegance',
    category: 'cinematic',
    icon: Star,
    description: 'Clean, minimal aesthetic with elegant simplicity',
    sceneDescription: 'A person in a minimalist white space with clean lines, soft diffused lighting creating subtle shadows, elegant and refined atmosphere',
    styleGuide: 'Minimalist composition, clean lines, negative space, soft lighting, elegant simplicity',
    visualElements: ['clean backgrounds', 'negative space', 'soft shadows', 'simple composition'],
    exampleScenes: [
      'Person against plain white background with soft light',
      'Minimalist composition with lots of negative space',
      'Clean lines and simple elegant framing'
    ],
    colorPalette: 'White, soft grays, subtle shadows, monochromatic',
    safetyTips: [
      'Focus on composition and space',
      'Emphasize elegance and refinement',
      'Keep visual elements simple'
    ],
    avoidWords: ['busy', 'cluttered', 'complex'],
    duration: 5,
    aspectRatio: '9:16'
  }
];

interface TemplateSelectorProps {
  onSelectTemplate: (template: VideoTemplate) => void;
  selectedTemplateId: string | null;
}

export const TemplateSelector = ({ onSelectTemplate, selectedTemplateId }: TemplateSelectorProps) => {
  const [filter, setFilter] = useState<string>('all');

  const categories = ['all', 'music-video', 'performance', 'cinematic', 'abstract', 'storytelling'];
  
  const filteredTemplates = filter === 'all' 
    ? templates 
    : templates.filter(t => t.category === filter);

  const getCategoryIcon = (category: string) => {
    switch(category) {
      case 'music-video': return Music;
      case 'performance': return Zap;
      case 'cinematic': return Film;
      case 'abstract': return Flame;
      case 'storytelling': return Heart;
      default: return Sparkles;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-heading text-lg font-semibold text-foreground flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Veo 3.1 Optimized Templates
          </h3>
          <p className="text-sm text-muted-foreground">Pre-configured for best results</p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 flex-wrap">
        {categories.map(cat => {
          const Icon = getCategoryIcon(cat);
          return (
            <Button
              key={cat}
              variant={filter === cat ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(cat)}
              className="capitalize"
            >
              <Icon className="w-3 h-3 mr-1" />
              {cat.replace('-', ' ')}
            </Button>
          );
        })}
      </div>

      {/* Template Grid */}
      <ScrollArea className="h-[600px] pr-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredTemplates.map(template => {
            const Icon = template.icon;
            const isSelected = selectedTemplateId === template.id;
            
            return (
              <Card 
                key={template.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  isSelected ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => onSelectTemplate(template)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <Icon className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{template.name}</CardTitle>
                        <CardDescription className="text-xs">
                          {template.category.replace('-', ' ')}
                        </CardDescription>
                      </div>
                    </div>
                    {template.premium && (
                      <Badge variant="secondary" className="text-xs">
                        <Star className="w-3 h-3 mr-1" />
                        Pro
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    {template.description}
                  </p>
                  
                  <div className="space-y-2">
                    <div className="text-xs font-medium text-foreground">Visual Style:</div>
                    <p className="text-xs text-muted-foreground">
                      {template.styleGuide}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {template.visualElements.slice(0, 3).map(element => (
                      <Badge key={element} variant="outline" className="text-xs">
                        {element}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-border/50">
                    <div className="text-xs text-muted-foreground">
                      {template.duration}s • {template.aspectRatio}
                    </div>
                    <Button 
                      size="sm" 
                      variant={isSelected ? 'default' : 'ghost'}
                    >
                      {isSelected ? 'Selected' : 'Use Template'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
};

export { templates };
