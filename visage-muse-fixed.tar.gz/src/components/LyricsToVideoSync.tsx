import { useState, useEffect } from 'react';
import { Music, Wand2, Play, Plus, Trash2, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';

export interface LyricScene {
  id: string;
  startTime: number; // seconds
  endTime: number;
  lyricLine: string;
  sceneDescription: string;
  visualMood: string;
}

interface LyricsToVideoSyncProps {
  lyrics: string;
  baseVisualStyle: string;
  onScenesGenerated: (scenes: LyricScene[]) => void;
}

export const LyricsToVideoSync = ({ 
  lyrics, 
  baseVisualStyle,
  onScenesGenerated 
}: LyricsToVideoSyncProps) => {
  const [scenes, setScenes] = useState<LyricScene[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [secondsPerLine, setSecondsPerLine] = useState(3);

  const analyzeLyrics = () => {
    setIsAnalyzing(true);
    
    // Split lyrics into lines
    const lines = lyrics
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0);

    if (lines.length === 0) {
      setIsAnalyzing(false);
      return;
    }

    // Generate scenes from lyrics
    const generatedScenes: LyricScene[] = lines.map((line, idx) => {
      const startTime = idx * secondsPerLine;
      const endTime = startTime + secondsPerLine;
      
      // Analyze lyric line for visual keywords
      const visualMood = detectVisualMood(line);
      const sceneDescription = generateSceneFromLyric(line, baseVisualStyle, visualMood);

      return {
        id: `scene-${idx}`,
        startTime,
        endTime,
        lyricLine: line,
        sceneDescription,
        visualMood
      };
    });

    setScenes(generatedScenes);
    onScenesGenerated(generatedScenes);
    setIsAnalyzing(false);
  };

  const detectVisualMood = (lyric: string): string => {
    const lower = lyric.toLowerCase();
    
    // Emotional/mood detection
    if (lower.match(/dark|shadow|night|alone|lost|pain/)) return 'dark moody';
    if (lower.match(/bright|light|sun|smile|happy|joy/)) return 'bright uplifting';
    if (lower.match(/dream|float|fly|sky|cloud/)) return 'ethereal dreamy';
    if (lower.match(/fire|burn|passion|heat/)) return 'intense dramatic';
    if (lower.match(/cold|ice|winter|freeze/)) return 'cool subdued';
    if (lower.match(/dance|move|groove|rhythm/)) return 'dynamic energetic';
    if (lower.match(/rain|tear|cry|sad/)) return 'melancholic soft';
    if (lower.match(/love|heart|kiss|together/)) return 'warm intimate';
    if (lower.match(/fight|strong|power|rise/)) return 'powerful bold';
    if (lower.match(/quiet|still|peace|calm/)) return 'serene peaceful';
    
    return 'neutral balanced';
  };

  const generateSceneFromLyric = (lyric: string, baseStyle: string, mood: string): string => {
    // Extract key visual words
    const lower = lyric.toLowerCase();
    
    // Build scene description
    let scene = baseStyle;
    
    // Add mood-based lighting
    if (mood.includes('dark')) {
      scene += '. Low key lighting with deep shadows';
    } else if (mood.includes('bright')) {
      scene += '. High key lighting with soft glow';
    } else if (mood.includes('ethereal')) {
      scene += '. Soft diffused lighting with dreamy atmosphere';
    } else if (mood.includes('intense')) {
      scene += '. Dramatic lighting with strong contrast';
    }
    
    // Add visual elements based on keywords
    if (lower.includes('rain')) scene += ', rainfall effects';
    if (lower.includes('light')) scene += ', glowing light elements';
    if (lower.includes('night')) scene += ', nighttime ambiance';
    if (lower.includes('fire')) scene += ', warm glowing effects';
    if (lower.includes('star')) scene += ', star-like particles';
    if (lower.includes('water') || lower.includes('ocean')) scene += ', water reflections';
    if (lower.includes('wind')) scene += ', flowing movement';
    
    // Add camera movement suggestion
    if (mood.includes('dynamic')) {
      scene += '. Camera slowly pushing in';
    } else if (mood.includes('intense')) {
      scene += '. Close-up with shallow depth of field';
    } else {
      scene += '. Steady composed framing';
    }
    
    return scene;
  };

  const updateScene = (id: string, updates: Partial<LyricScene>) => {
    const updated = scenes.map(s => s.id === id ? { ...s, ...updates } : s);
    setScenes(updated);
    onScenesGenerated(updated);
  };

  const removeScene = (id: string) => {
    const updated = scenes.filter(s => s.id !== id);
    // Recalculate timing
    const recalculated = updated.map((s, idx) => ({
      ...s,
      startTime: idx * secondsPerLine,
      endTime: (idx + 1) * secondsPerLine
    }));
    setScenes(recalculated);
    onScenesGenerated(recalculated);
  };

  const addScene = () => {
    const lastScene = scenes[scenes.length - 1];
    const startTime = lastScene ? lastScene.endTime : 0;
    const newScene: LyricScene = {
      id: `scene-${Date.now()}`,
      startTime,
      endTime: startTime + secondsPerLine,
      lyricLine: '',
      sceneDescription: baseVisualStyle,
      visualMood: 'neutral'
    };
    const updated = [...scenes, newScene];
    setScenes(updated);
    onScenesGenerated(updated);
  };

  const totalDuration = scenes.reduce((max, s) => Math.max(max, s.endTime), 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-primary" />
            <div>
              <CardTitle className="text-base">Lyrics-to-Video Sync</CardTitle>
              <CardDescription className="text-xs">
                AI-powered scene generation synchronized to your lyrics
              </CardDescription>
            </div>
          </div>
          <Badge className="text-xs">
            ✨ Exclusive Feature
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!lyrics && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>No lyrics provided</AlertTitle>
            <AlertDescription>
              Add lyrics in the input above to use this feature
            </AlertDescription>
          </Alert>
        )}

        {lyrics && scenes.length === 0 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs">Seconds per Lyric Line</Label>
              <Input
                type="number"
                min={2}
                max={5}
                value={secondsPerLine}
                onChange={(e) => setSecondsPerLine(parseInt(e.target.value) || 3)}
                className="text-sm"
              />
              <p className="text-xs text-muted-foreground">
                How long should each lyric line be displayed? (2-5 seconds recommended)
              </p>
            </div>

            <Button
              onClick={analyzeLyrics}
              disabled={isAnalyzing}
              className="w-full"
              size="lg"
            >
              <Wand2 className="w-4 h-4 mr-2" />
              {isAnalyzing ? 'Analyzing Lyrics...' : 'Generate Scene Breakdown'}
            </Button>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="text-xs">
                This AI will analyze your lyrics and automatically generate optimized scene descriptions 
                for each line, matching visual mood to lyrical content.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {scenes.length > 0 && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="bg-muted/50 rounded-lg p-4 space-y-2">
              <div className="font-medium text-sm flex items-center gap-2">
                <Play className="w-4 h-4 text-primary" />
                Sync Summary
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Total Scenes:</span>
                  <span className="ml-2 font-medium">{scenes.length}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Duration:</span>
                  <span className="ml-2 font-medium">{totalDuration}s</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Avg Scene:</span>
                  <span className="ml-2 font-medium">{secondsPerLine}s</span>
                </div>
              </div>
            </div>

            {/* Scenes List */}
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-3">
                {scenes.map((scene, idx) => (
                  <div key={scene.id}>
                    <Card className="border-2">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">
                              {scene.startTime}s - {scene.endTime}s
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {scene.visualMood}
                            </Badge>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeScene(scene.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="space-y-2">
                          <Label className="text-xs text-muted-foreground">Lyric Line</Label>
                          <div className="p-3 bg-muted/50 rounded-md">
                            <p className="text-sm font-medium italic">
                              "{scene.lyricLine}"
                            </p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="text-xs">Generated Scene Description</Label>
                          <Textarea
                            value={scene.sceneDescription}
                            onChange={(e) => updateScene(scene.id, { sceneDescription: e.target.value })}
                            rows={3}
                            className="text-xs"
                          />
                        </div>

                        <div className="text-xs text-muted-foreground">
                          💡 Edit the scene description to fine-tune the visual for this lyric
                        </div>
                      </CardContent>
                    </Card>
                    {idx < scenes.length - 1 && <Separator className="my-3" />}
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Actions */}
            <div className="flex gap-2 pt-2 border-t">
              <Button
                onClick={addScene}
                variant="outline"
                className="flex-1"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Scene
              </Button>
              <Button
                onClick={analyzeLyrics}
                variant="outline"
                className="flex-1"
              >
                <Wand2 className="w-4 h-4 mr-2" />
                Regenerate
              </Button>
            </div>

            {/* Instructions */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle className="text-sm">How This Works</AlertTitle>
              <AlertDescription className="text-xs space-y-1 mt-2">
                <p>1. Each scene will be generated as a separate video clip</p>
                <p>2. Download all clips when complete</p>
                <p>3. Import clips + your music into a video editor</p>
                <p>4. Arrange clips on timeline matching the timestamps</p>
                <p>5. Export final music video with perfectly synced visuals!</p>
              </AlertDescription>
            </Alert>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
