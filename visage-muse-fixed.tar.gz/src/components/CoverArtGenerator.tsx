import { useState } from 'react';
import { Palette, Download, Wand2, Copy, Check } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

interface SEOMetadata {
  youtubeTitle: string;
  youtubeDescription: string;
  youtubeTags: string[];
  spotifyTitle: string;
  spotifyDescription: string;
  instagramCaption: string;
  tiktokCaption: string;
}

interface CoverArtGeneratorProps {
  videoPrompt: string;
  lyrics?: string;
  artistName?: string;
  trackTitle?: string;
}

export const CoverArtGenerator = ({ 
  videoPrompt, 
  lyrics, 
  artistName = '', 
  trackTitle = '' 
}: CoverArtGeneratorProps) => {
  const [metadata, setMetadata] = useState<SEOMetadata>({
    youtubeTitle: '',
    youtubeDescription: '',
    youtubeTags: [],
    spotifyTitle: '',
    spotifyDescription: '',
    instagramCaption: '',
    tiktokCaption: ''
  });
  const [coverPrompt, setCoverPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const generateSEOMetadata = () => {
    setIsGenerating(true);
    
    // Extract key themes from video prompt
    const themes = videoPrompt.toLowerCase();
    const style = themes.includes('cyberpunk') ? 'cyberpunk' :
                  themes.includes('dreamy') ? 'dreamy ethereal' :
                  themes.includes('neon') ? 'neon aesthetic' :
                  'cinematic';

    // Generate metadata
    const title = trackTitle || 'Untitled Track';
    const artist = artistName || 'Artist';
    
    const newMetadata: SEOMetadata = {
      youtubeTitle: `${artist} - ${title} [Official Music Video]`,
      youtubeDescription: `${artist} - ${title}

${lyrics ? lyrics.split('\n').slice(0, 4).join('\n') : 'New music video featuring stunning AI-generated visuals.'}

🎵 Stream on all platforms
🎬 Directed and produced with AI
✨ ${style} aesthetic

#MusicVideo #${artist.replace(/\s/g, '')} #AIArt #${style.replace(/\s/g, '')}

© ${new Date().getFullYear()} ${artist}`,
      
      youtubeTags: [
        artist.toLowerCase(),
        title.toLowerCase(),
        'music video',
        'official video',
        style,
        'ai generated',
        'veo',
        'music',
        'new music',
        `${artist.toLowerCase()} ${title.toLowerCase()}`
      ],

      spotifyTitle: `${title} - ${artist}`,
      spotifyDescription: `${style} vibes meet cutting-edge visuals. Experience ${title} by ${artist}.`,

      instagramCaption: `✨ ${title} - OUT NOW

${lyrics ? lyrics.split('\n')[0] : '🎵'}

Watch the full video (link in bio)

#newmusic #musicvideo #${artist.replace(/\s/g, '')} #${style.replace(/\s/g, '')} #aiart`,

      tiktokCaption: `${title} - ${artist} 🎵✨ #newmusic #musicvideo #${style.replace(/\s/g, '')} #aiart #fyp`
    };

    // Generate cover art prompt
    const generatedCoverPrompt = `Album cover art for "${title}" by ${artist}. ${style} aesthetic with bold typography. The album title "${title}" displayed prominently. Visual style inspired by: ${videoPrompt.slice(0, 100)}. Square format, professional design, eye-catching composition.`;
    
    setCoverPrompt(generatedCoverPrompt);
    setMetadata(newMetadata);
    setIsGenerating(false);
    toast.success('SEO metadata generated!');
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      toast.success('Copied to clipboard!');
      setTimeout(() => setCopiedField(null), 2000);
    } catch (err) {
      toast.error('Failed to copy');
    }
  };

  const downloadMetadata = () => {
    const content = `
# SEO METADATA FOR: ${trackTitle || 'Untitled'} by ${artistName || 'Artist'}

## YouTube
**Title:** ${metadata.youtubeTitle}

**Description:**
${metadata.youtubeDescription}

**Tags:** ${metadata.youtubeTags.join(', ')}

---

## Spotify
**Title:** ${metadata.spotifyTitle}
**Description:** ${metadata.spotifyDescription}

---

## Instagram
${metadata.instagramCaption}

---

## TikTok
${metadata.tiktokCaption}

---

## Cover Art Prompt
${coverPrompt}
`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${trackTitle || 'track'}_metadata.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Metadata downloaded!');
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-primary" />
            <div>
              <CardTitle className="text-base">Cover Art & SEO Generator</CardTitle>
              <CardDescription className="text-xs">
                Generate album cover and platform-optimized metadata
              </CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className="text-xs">
            <Wand2 className="w-3 h-3 mr-1" />
            Pro Feature
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Artist and Track Info */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-xs">Artist Name</Label>
            <Input
              placeholder="Artist name"
              value={artistName}
              className="text-sm"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-xs">Track Title</Label>
            <Input
              placeholder="Track title"
              value={trackTitle}
              className="text-sm"
            />
          </div>
        </div>

        {/* Generate Button */}
        <Button
          onClick={generateSEOMetadata}
          disabled={isGenerating || !videoPrompt}
          className="w-full"
        >
          <Wand2 className="w-4 h-4 mr-2" />
          {isGenerating ? 'Generating...' : 'Generate SEO Metadata & Cover Prompt'}
        </Button>

        {/* Cover Art Prompt */}
        {coverPrompt && (
          <div className="space-y-2">
            <Label className="text-xs flex items-center justify-between">
              <span>Cover Art Generation Prompt</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(coverPrompt, 'cover')}
              >
                {copiedField === 'cover' ? (
                  <Check className="w-3 h-3" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </Button>
            </Label>
            <Textarea
              value={coverPrompt}
              onChange={(e) => setCoverPrompt(e.target.value)}
              rows={4}
              className="text-xs font-mono"
            />
            <p className="text-xs text-muted-foreground">
              💡 Use this prompt in DALL-E, Midjourney, or Stable Diffusion to create your album cover
            </p>
          </div>
        )}

        {/* SEO Metadata Tabs */}
        {metadata.youtubeTitle && (
          <Tabs defaultValue="youtube" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="youtube" className="text-xs">YouTube</TabsTrigger>
              <TabsTrigger value="spotify" className="text-xs">Spotify</TabsTrigger>
              <TabsTrigger value="instagram" className="text-xs">Instagram</TabsTrigger>
              <TabsTrigger value="tiktok" className="text-xs">TikTok</TabsTrigger>
            </TabsList>

            <TabsContent value="youtube" className="space-y-3 mt-3">
              <div className="space-y-2">
                <Label className="text-xs flex items-center justify-between">
                  <span>Title (max 100 chars)</span>
                  <span className="text-muted-foreground">{metadata.youtubeTitle.length}/100</span>
                </Label>
                <div className="flex gap-2">
                  <Input
                    value={metadata.youtubeTitle}
                    onChange={(e) => setMetadata({...metadata, youtubeTitle: e.target.value})}
                    maxLength={100}
                    className="text-sm"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(metadata.youtubeTitle, 'yt-title')}
                  >
                    {copiedField === 'yt-title' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs flex items-center justify-between">
                  <span>Description (max 5000 chars)</span>
                  <span className="text-muted-foreground">{metadata.youtubeDescription.length}/5000</span>
                </Label>
                <div className="space-y-2">
                  <Textarea
                    value={metadata.youtubeDescription}
                    onChange={(e) => setMetadata({...metadata, youtubeDescription: e.target.value})}
                    rows={6}
                    maxLength={5000}
                    className="text-xs font-mono"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(metadata.youtubeDescription, 'yt-desc')}
                    className="w-full"
                  >
                    {copiedField === 'yt-desc' ? <Check className="w-3 h-3 mr-2" /> : <Copy className="w-3 h-3 mr-2" />}
                    Copy Description
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Tags</Label>
                <div className="flex flex-wrap gap-1">
                  {metadata.youtubeTags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(metadata.youtubeTags.join(', '), 'yt-tags')}
                  className="w-full"
                >
                  {copiedField === 'yt-tags' ? <Check className="w-3 h-3 mr-2" /> : <Copy className="w-3 h-3 mr-2" />}
                  Copy Tags
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="spotify" className="space-y-3 mt-3">
              <div className="space-y-2">
                <Label className="text-xs">Title</Label>
                <div className="flex gap-2">
                  <Input
                    value={metadata.spotifyTitle}
                    onChange={(e) => setMetadata({...metadata, spotifyTitle: e.target.value})}
                    className="text-sm"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(metadata.spotifyTitle, 'sp-title')}
                  >
                    {copiedField === 'sp-title' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Description</Label>
                <div className="space-y-2">
                  <Textarea
                    value={metadata.spotifyDescription}
                    onChange={(e) => setMetadata({...metadata, spotifyDescription: e.target.value})}
                    rows={3}
                    className="text-sm"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(metadata.spotifyDescription, 'sp-desc')}
                    className="w-full"
                  >
                    {copiedField === 'sp-desc' ? <Check className="w-3 h-3 mr-2" /> : <Copy className="w-3 h-3 mr-2" />}
                    Copy Description
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="instagram" className="space-y-3 mt-3">
              <div className="space-y-2">
                <Label className="text-xs flex items-center justify-between">
                  <span>Caption (max 2200 chars)</span>
                  <span className="text-muted-foreground">{metadata.instagramCaption.length}/2200</span>
                </Label>
                <div className="space-y-2">
                  <Textarea
                    value={metadata.instagramCaption}
                    onChange={(e) => setMetadata({...metadata, instagramCaption: e.target.value})}
                    rows={6}
                    maxLength={2200}
                    className="text-sm"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(metadata.instagramCaption, 'ig-caption')}
                    className="w-full"
                  >
                    {copiedField === 'ig-caption' ? <Check className="w-3 h-3 mr-2" /> : <Copy className="w-3 h-3 mr-2" />}
                    Copy Caption
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tiktok" className="space-y-3 mt-3">
              <div className="space-y-2">
                <Label className="text-xs flex items-center justify-between">
                  <span>Caption (max 300 chars)</span>
                  <span className="text-muted-foreground">{metadata.tiktokCaption.length}/300</span>
                </Label>
                <div className="space-y-2">
                  <Textarea
                    value={metadata.tiktokCaption}
                    onChange={(e) => setMetadata({...metadata, tiktokCaption: e.target.value})}
                    rows={3}
                    maxLength={300}
                    className="text-sm"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(metadata.tiktokCaption, 'tt-caption')}
                    className="w-full"
                  >
                    {copiedField === 'tt-caption' ? <Check className="w-3 h-3 mr-2" /> : <Copy className="w-3 h-3 mr-2" />}
                    Copy Caption
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}

        {/* Download All */}
        {metadata.youtubeTitle && (
          <Button
            onClick={downloadMetadata}
            variant="outline"
            className="w-full"
          >
            <Download className="w-4 h-4 mr-2" />
            Download All Metadata
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
