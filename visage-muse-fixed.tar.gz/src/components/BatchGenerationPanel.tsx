import { useState } from 'react';
import { Layers, Plus, Trash2, Copy, Play } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

export interface BatchScene {
  id: string;
  sceneDescription: string;
  duration: number;
  order: number;
}

interface BatchGenerationPanelProps {
  onScenesChange: (scenes: BatchScene[]) => void;
  aspectRatio: string;
}

export const BatchGenerationPanel = ({ onScenesChange, aspectRatio }: BatchGenerationPanelProps) => {
  const [scenes, setScenes] = useState<BatchScene[]>([
    { id: '1', sceneDescription: '', duration: 5, order: 1 }
  ]);

  const addScene = () => {
    const newScene: BatchScene = {
      id: Date.now().toString(),
      sceneDescription: '',
      duration: 5,
      order: scenes.length + 1
    };
    const updatedScenes = [...scenes, newScene];
    setScenes(updatedScenes);
    onScenesChange(updatedScenes);
  };

  const removeScene = (id: string) => {
    if (scenes.length === 1) return; // Keep at least one scene
    const updatedScenes = scenes
      .filter(s => s.id !== id)
      .map((s, idx) => ({ ...s, order: idx + 1 }));
    setScenes(updatedScenes);
    onScenesChange(updatedScenes);
  };

  const duplicateScene = (scene: BatchScene) => {
    const newScene: BatchScene = {
      id: Date.now().toString(),
      sceneDescription: scene.sceneDescription,
      duration: scene.duration,
      order: scenes.length + 1
    };
    const updatedScenes = [...scenes, newScene];
    setScenes(updatedScenes);
    onScenesChange(updatedScenes);
  };

  const updateScene = (id: string, updates: Partial<BatchScene>) => {
    const updatedScenes = scenes.map(s => 
      s.id === id ? { ...s, ...updates } : s
    );
    setScenes(updatedScenes);
    onScenesChange(updatedScenes);
  };

  const moveScene = (id: string, direction: 'up' | 'down') => {
    const idx = scenes.findIndex(s => s.id === id);
    if (idx === -1) return;
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === scenes.length - 1) return;

    const newScenes = [...scenes];
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    [newScenes[idx], newScenes[swapIdx]] = [newScenes[swapIdx], newScenes[idx]];
    
    // Update order numbers
    const reordered = newScenes.map((s, i) => ({ ...s, order: i + 1 }));
    setScenes(reordered);
    onScenesChange(reordered);
  };

  const totalDuration = scenes.reduce((sum, s) => sum + s.duration, 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-primary" />
            <div>
              <CardTitle className="text-base">Batch Scene Generation</CardTitle>
              <CardDescription className="text-xs">
                Create multiple video clips that can be stitched together
              </CardDescription>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm font-medium">{scenes.length} scenes</div>
            <div className="text-xs text-muted-foreground">{totalDuration}s total</div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            {scenes.map((scene, idx) => (
              <div key={scene.id}>
                <Card className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Scene {scene.order}</Badge>
                        <span className="text-xs text-muted-foreground">
                          {scene.duration}s
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        {idx > 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => moveScene(scene.id, 'up')}
                          >
                            ↑
                          </Button>
                        )}
                        {idx < scenes.length - 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => moveScene(scene.id, 'down')}
                          >
                            ↓
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => duplicateScene(scene)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                        {scenes.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeScene(scene.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <Label className="text-xs">Scene Description</Label>
                      <Textarea
                        placeholder="Describe the visual scene (focus on lighting, composition, and mood)"
                        value={scene.sceneDescription}
                        onChange={(e) => updateScene(scene.id, { sceneDescription: e.target.value })}
                        rows={3}
                        className="text-sm"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Duration (seconds)</Label>
                      <Input
                        type="number"
                        min={3}
                        max={8}
                        value={scene.duration}
                        onChange={(e) => updateScene(scene.id, { duration: parseInt(e.target.value) || 5 })}
                        className="text-sm"
                      />
                    </div>

                    <div className="text-xs text-muted-foreground">
                      💡 Tip: Each scene will be generated separately and can be stitched in post-production
                    </div>
                  </CardContent>
                </Card>
                {idx < scenes.length - 1 && <Separator className="my-4" />}
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="flex gap-2 pt-2 border-t">
          <Button
            onClick={addScene}
            variant="outline"
            className="flex-1"
            disabled={scenes.length >= 10}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Scene {scenes.length >= 10 && '(Max 10)'}
          </Button>
        </div>

        <div className="bg-muted/50 rounded-lg p-4 space-y-2">
          <div className="font-medium text-sm flex items-center gap-2">
            <Play className="w-4 h-4 text-primary" />
            Batch Generation Summary
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-muted-foreground">Total Scenes:</span>
              <span className="ml-2 font-medium">{scenes.length}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Total Duration:</span>
              <span className="ml-2 font-medium">{totalDuration}s</span>
            </div>
            <div>
              <span className="text-muted-foreground">Aspect Ratio:</span>
              <span className="ml-2 font-medium">{aspectRatio}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Est. Time:</span>
              <span className="ml-2 font-medium">{scenes.length * 2}-{scenes.length * 3} min</span>
            </div>
          </div>
        </div>

        <div className="text-xs text-muted-foreground space-y-1">
          <p>📌 Each scene generates independently for maximum quality</p>
          <p>📌 Use consistent visual style across scenes for cohesive results</p>
          <p>📌 Download and stitch with video editor for final music video</p>
        </div>
      </CardContent>
    </Card>
  );
};
