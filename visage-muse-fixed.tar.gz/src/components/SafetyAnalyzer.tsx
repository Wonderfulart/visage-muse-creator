import { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, XCircle, Info, Shield } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Button } from '@/components/ui/button';

interface SafetyAnalysis {
  score: 'safe' | 'warning' | 'danger';
  issues: Array<{
    type: 'banned-word' | 'sensitive-content' | 'ambiguous' | 'tip';
    severity: 'high' | 'medium' | 'low';
    message: string;
    suggestion?: string;
  }>;
  suggestions: string[];
}

// Veo 3.1 specific restrictions
const BANNED_WORDS = [
  'weapon', 'gun', 'knife', 'blood', 'violence', 'violent', 'kill', 'death', 'dead',
  'nude', 'naked', 'explicit', 'sexual', 'nsfw', 'porn',
  'drug', 'cocaine', 'meth', 'heroin',
  'suicide', 'self-harm',
  'terrorist', 'bomb', 'explosion',
  'hate', 'racist', 'nazi',
  'child', 'kid', 'minor', 'baby', 'toddler', // Veo has strict child protection
];

const SENSITIVE_WORDS = [
  'intimate', 'provocative', 'seductive', 'kissing', 'romance',
  'crowd', 'protest', 'riot', 'police',
  'fire', 'burning', 'smoke', // can be flagged if combined with people
  'crying', 'screaming', 'pain',
  'accident', 'crash', 'injury',
  'religious', 'political',
];

const ACTION_WORDS_TO_AVOID = [
  'running', 'jumping', 'fighting', 'dancing', 'climbing', 'falling',
  'eating', 'drinking', 'smoking',
  'driving', 'riding',
  'swimming', 'diving',
];

const BETTER_ALTERNATIVES = {
  'person running': 'figure in motion with dynamic energy',
  'dancing': 'rhythmic movement to music',
  'jumping': 'elevated pose with energy',
  'crowd': 'atmospheric environment',
  'explicit': 'artistic',
  'violent': 'dramatic',
  'fighting': 'choreographed movement',
  'kissing': 'intimate moment (caution: may be flagged)',
  'child': 'young person (avoid if possible)',
  'crying': 'emotional expression',
  'fire': 'warm glowing light',
};

const VEO_TIPS = [
  'Describe VISUALS not ACTIONS: Instead of "person running", use "figure in motion with dynamic movement"',
  'Focus on LIGHTING and ATMOSPHERE: "Dramatic rim lighting" works better than action descriptions',
  'Use CINEMATIC language: "Wide shot", "close-up", "shallow depth of field"',
  'Avoid PEOPLE INTERACTIONS: Veo struggles with multiple people interacting',
  'Keep it ABSTRACT when needed: "Flowing movement" instead of specific actions',
  'Emphasize MOOD over NARRATIVE: Describe the feeling, not the story',
  'Use STATIC POSES: Standing, sitting, contemplating work better than actions',
  'Reference CAMERA ANGLES: "Low angle shot", "bird\'s eye view", "dutch angle"',
];

interface SafetyAnalyzerProps {
  prompt: string;
  lyrics?: string;
  onAnalysisComplete?: (analysis: SafetyAnalysis) => void;
}

export const SafetyAnalyzer = ({ prompt, lyrics, onAnalysisComplete }: SafetyAnalyzerProps) => {
  const [analysis, setAnalysis] = useState<SafetyAnalysis | null>(null);
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    analyzeContent();
  }, [prompt, lyrics]);

  const analyzeContent = () => {
    const issues: SafetyAnalysis['issues'] = [];
    const suggestions: string[] = [];
    const combinedText = `${prompt} ${lyrics || ''}`.toLowerCase();

    // Check for banned words
    BANNED_WORDS.forEach(word => {
      if (combinedText.includes(word)) {
        issues.push({
          type: 'banned-word',
          severity: 'high',
          message: `Contains banned word: "${word}"`,
          suggestion: 'Remove this word to avoid rejection'
        });
      }
    });

    // Check for sensitive words
    SENSITIVE_WORDS.forEach(word => {
      if (combinedText.includes(word)) {
        issues.push({
          type: 'sensitive-content',
          severity: 'medium',
          message: `Sensitive word detected: "${word}"`,
          suggestion: BETTER_ALTERNATIVES[word] || 'Consider rephrasing'
        });
      }
    });

    // Check for action words
    ACTION_WORDS_TO_AVOID.forEach(word => {
      if (combinedText.includes(word)) {
        issues.push({
          type: 'ambiguous',
          severity: 'low',
          message: `Action word: "${word}" - may cause unpredictable results`,
          suggestion: BETTER_ALTERNATIVES[word] || 'Describe the visual result, not the action'
        });
      }
    });

    // Check for specific problematic patterns
    if (combinedText.match(/multiple (people|person)/)) {
      issues.push({
        type: 'tip',
        severity: 'medium',
        message: 'Multiple people interactions are challenging for Veo',
        suggestion: 'Focus on a single subject for best results'
      });
    }

    if (combinedText.length < 20) {
      issues.push({
        type: 'tip',
        severity: 'low',
        message: 'Description is very short',
        suggestion: 'Add more visual details for better results'
      });
    }

    // Determine overall score
    const hasHighSeverity = issues.some(i => i.severity === 'high');
    const hasMediumSeverity = issues.some(i => i.severity === 'medium');
    
    const score: SafetyAnalysis['score'] = 
      hasHighSeverity ? 'danger' : 
      hasMediumSeverity ? 'warning' : 
      'safe';

    // Generate suggestions
    if (score !== 'safe') {
      suggestions.push('Review flagged content above');
    }
    if (combinedText.length > 500) {
      suggestions.push('Consider shortening for clarity');
    }
    if (!combinedText.match(/cinematic|shot|lighting|camera/)) {
      suggestions.push('Add cinematic/technical terms for better control');
    }

    const newAnalysis = { score, issues, suggestions };
    setAnalysis(newAnalysis);
    onAnalysisComplete?.(newAnalysis);
  };

  if (!analysis || (!prompt && !lyrics)) {
    return null;
  }

  const getScoreColor = () => {
    switch(analysis.score) {
      case 'safe': return 'text-green-500';
      case 'warning': return 'text-yellow-500';
      case 'danger': return 'text-red-500';
    }
  };

  const getScoreIcon = () => {
    switch(analysis.score) {
      case 'safe': return CheckCircle;
      case 'warning': return AlertTriangle;
      case 'danger': return XCircle;
    }
  };

  const ScoreIcon = getScoreIcon();

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card className="border-2">
        <CardHeader className="pb-3">
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                <div>
                  <CardTitle className="text-base">Safety Analyzer</CardTitle>
                  <CardDescription className="text-xs">
                    Veo 3.1 content guidelines check
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <ScoreIcon className={`w-5 h-5 ${getScoreColor()}`} />
                <Badge variant={
                  analysis.score === 'safe' ? 'default' : 
                  analysis.score === 'warning' ? 'secondary' : 
                  'destructive'
                }>
                  {analysis.score.toUpperCase()}
                </Badge>
              </div>
            </div>
          </CollapsibleTrigger>
        </CardHeader>

        <CollapsibleContent>
          <CardContent className="space-y-4">
            {/* Issues */}
            {analysis.issues.length > 0 && (
              <div className="space-y-2">
                <div className="text-sm font-medium">Issues Found:</div>
                {analysis.issues.map((issue, idx) => (
                  <Alert key={idx} variant={issue.severity === 'high' ? 'destructive' : 'default'}>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle className="text-sm">{issue.message}</AlertTitle>
                    {issue.suggestion && (
                      <AlertDescription className="text-xs mt-1">
                        💡 {issue.suggestion}
                      </AlertDescription>
                    )}
                  </Alert>
                ))}
              </div>
            )}

            {/* Veo Tips */}
            <div className="space-y-2">
              <div className="text-sm font-medium flex items-center gap-2">
                <Info className="w-4 h-4" />
                Veo 3.1 Pro Tips:
              </div>
              <div className="space-y-1">
                {VEO_TIPS.slice(0, 4).map((tip, idx) => (
                  <div key={idx} className="text-xs text-muted-foreground flex gap-2">
                    <span className="text-primary">•</span>
                    <span>{tip}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Better Alternatives */}
            {analysis.score !== 'safe' && (
              <div className="space-y-2">
                <div className="text-sm font-medium">Suggested Rewrites:</div>
                <div className="space-y-1 text-xs">
                  {Object.entries(BETTER_ALTERNATIVES).slice(0, 5).map(([bad, good]) => (
                    <div key={bad} className="flex gap-2 items-start">
                      <XCircle className="w-3 h-3 text-red-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground line-through">{bad}</span>
                      <span>→</span>
                      <CheckCircle className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-foreground">{good}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* All Clear Message */}
            {analysis.score === 'safe' && analysis.issues.length === 0 && (
              <Alert>
                <CheckCircle className="h-4 w-4 text-green-500" />
                <AlertTitle>Looking Good!</AlertTitle>
                <AlertDescription>
                  No obvious issues detected. Your content should pass Veo 3.1 guidelines.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};
